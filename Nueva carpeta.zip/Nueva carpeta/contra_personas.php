<?php
$valor = $_POST["valor"];
$edad = $_POST["edad"];
$des = $valor*0.2;
$total = $valor-$des;
if($edad<=0){
    die("edad no valida");  
}
if($valor<=0){
    die("valor no valido");
}

if($edad>=60)
{
echo"te daremos un descuento de un 20%: <br>".$total;
}
else
{
    
 echo " no has ganado ningun descuento <br>". $valor;
}




?>